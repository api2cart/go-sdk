# \CategoryAPI

All URIs are relative to *https://api.api2cart.local.com/v1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CategoryAdd**](CategoryAPI.md#CategoryAdd) | **Post** /category.add.json | category.add
[**CategoryAddBatch**](CategoryAPI.md#CategoryAddBatch) | **Post** /category.add.batch.json | category.add.batch
[**CategoryAssign**](CategoryAPI.md#CategoryAssign) | **Post** /category.assign.json | category.assign
[**CategoryCount**](CategoryAPI.md#CategoryCount) | **Get** /category.count.json | category.count
[**CategoryDelete**](CategoryAPI.md#CategoryDelete) | **Delete** /category.delete.json | category.delete
[**CategoryDeleteBatch**](CategoryAPI.md#CategoryDeleteBatch) | **Post** /category.delete.batch.json | category.delete.batch
[**CategoryFind**](CategoryAPI.md#CategoryFind) | **Get** /category.find.json | category.find
[**CategoryImageAdd**](CategoryAPI.md#CategoryImageAdd) | **Post** /category.image.add.json | category.image.add
[**CategoryImageDelete**](CategoryAPI.md#CategoryImageDelete) | **Delete** /category.image.delete.json | category.image.delete
[**CategoryInfo**](CategoryAPI.md#CategoryInfo) | **Get** /category.info.json | category.info
[**CategoryList**](CategoryAPI.md#CategoryList) | **Get** /category.list.json | category.list
[**CategoryUnassign**](CategoryAPI.md#CategoryUnassign) | **Post** /category.unassign.json | category.unassign
[**CategoryUpdate**](CategoryAPI.md#CategoryUpdate) | **Put** /category.update.json | category.update



## CategoryAdd

> CategoryAdd200Response CategoryAdd(ctx).Name(name).Description(description).ShortDescription(shortDescription).ParentId(parentId).Avail(avail).CreatedTime(createdTime).ModifiedTime(modifiedTime).SortOrder(sortOrder).MetaTitle(metaTitle).MetaDescription(metaDescription).MetaKeywords(metaKeywords).SeoUrl(seoUrl).StoreId(storeId).StoresIds(storesIds).LangId(langId).IdempotencyKey(idempotencyKey).Execute()

category.add



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	name := "Shoes" // string | Defines category's name that has to be added
	description := "Test category" // string | Defines category's description (optional)
	shortDescription := "Short description. This is very short description" // string | Defines short description (optional)
	parentId := "6" // string | Adds categories specified by parent id (optional)
	avail := false // bool | Defines category's visibility status (optional) (default to true)
	createdTime := "2014-01-30 15:58:41" // string | Entity's date creation (optional)
	modifiedTime := "2014-07-30 15:58:41" // string | Entity's date modification (optional)
	sortOrder := int32(2) // int32 | Sort number in the list (optional) (default to 0)
	metaTitle := "category,test" // string | Defines unique meta title for each entity (optional)
	metaDescription := "category,test" // string | Defines unique meta description of a entity (optional)
	metaKeywords := "category,test" // string | Defines unique meta keywords for each entity (optional)
	seoUrl := "category,test" // string | Defines unique category's URL for SEO (optional)
	storeId := "1" // string | Store Id (optional)
	storesIds := "1,2" // string | Create category in the stores that is specified by comma-separated stores' id (optional)
	langId := "3" // string | Language id (optional)
	idempotencyKey := "098f6bcd4621d373cade4e832627b4f6" // string | A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> (optional)

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.CategoryAPI.CategoryAdd(context.Background()).Name(name).Description(description).ShortDescription(shortDescription).ParentId(parentId).Avail(avail).CreatedTime(createdTime).ModifiedTime(modifiedTime).SortOrder(sortOrder).MetaTitle(metaTitle).MetaDescription(metaDescription).MetaKeywords(metaKeywords).SeoUrl(seoUrl).StoreId(storeId).StoresIds(storesIds).LangId(langId).IdempotencyKey(idempotencyKey).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `CategoryAPI.CategoryAdd``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `CategoryAdd`: CategoryAdd200Response
	fmt.Fprintf(os.Stdout, "Response from `CategoryAPI.CategoryAdd`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCategoryAddRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **string** | Defines category&#39;s name that has to be added | 
 **description** | **string** | Defines category&#39;s description | 
 **shortDescription** | **string** | Defines short description | 
 **parentId** | **string** | Adds categories specified by parent id | 
 **avail** | **bool** | Defines category&#39;s visibility status | [default to true]
 **createdTime** | **string** | Entity&#39;s date creation | 
 **modifiedTime** | **string** | Entity&#39;s date modification | 
 **sortOrder** | **int32** | Sort number in the list | [default to 0]
 **metaTitle** | **string** | Defines unique meta title for each entity | 
 **metaDescription** | **string** | Defines unique meta description of a entity | 
 **metaKeywords** | **string** | Defines unique meta keywords for each entity | 
 **seoUrl** | **string** | Defines unique category&#39;s URL for SEO | 
 **storeId** | **string** | Store Id | 
 **storesIds** | **string** | Create category in the stores that is specified by comma-separated stores&#39; id | 
 **langId** | **string** | Language id | 
 **idempotencyKey** | **string** | A unique identifier associated with a specific request. Repeated requests with the same &lt;strong&gt;idempotency_key&lt;/strong&gt; return a cached response without re-executing the business logic. &lt;strong&gt;Please note that the cache lifetime is 15 minutes.&lt;/strong&gt; | 

### Return type

[**CategoryAdd200Response**](CategoryAdd200Response.md)

### Authorization

[StoreKeyAuth](../README.md#StoreKeyAuth), [ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CategoryAddBatch

> CategoryAddBatch200Response CategoryAddBatch(ctx).CategoryAddBatch(categoryAddBatch).Execute()

category.add.batch



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	categoryAddBatch := *openapiclient.NewCategoryAddBatch([]openapiclient.CategoryAddBatchPayloadInner{*openapiclient.NewCategoryAddBatchPayloadInner("Name_example")}) // CategoryAddBatch | 

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.CategoryAPI.CategoryAddBatch(context.Background()).CategoryAddBatch(categoryAddBatch).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `CategoryAPI.CategoryAddBatch``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `CategoryAddBatch`: CategoryAddBatch200Response
	fmt.Fprintf(os.Stdout, "Response from `CategoryAPI.CategoryAddBatch`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCategoryAddBatchRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **categoryAddBatch** | [**CategoryAddBatch**](CategoryAddBatch.md) |  | 

### Return type

[**CategoryAddBatch200Response**](CategoryAddBatch200Response.md)

### Authorization

[StoreKeyAuth](../README.md#StoreKeyAuth), [ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CategoryAssign

> ModelResponseCategoryAssign CategoryAssign(ctx).CategoryId(categoryId).ProductId(productId).StoreId(storeId).IdempotencyKey(idempotencyKey).Execute()

category.assign



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	categoryId := "6" // string | Defines category assign, specified by category id
	productId := "10" // string | Defines category assign to the product, specified by product id
	storeId := "1" // string | Store Id (optional)
	idempotencyKey := "098f6bcd4621d373cade4e832627b4f6" // string | A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> (optional)

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.CategoryAPI.CategoryAssign(context.Background()).CategoryId(categoryId).ProductId(productId).StoreId(storeId).IdempotencyKey(idempotencyKey).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `CategoryAPI.CategoryAssign``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `CategoryAssign`: ModelResponseCategoryAssign
	fmt.Fprintf(os.Stdout, "Response from `CategoryAPI.CategoryAssign`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCategoryAssignRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **categoryId** | **string** | Defines category assign, specified by category id | 
 **productId** | **string** | Defines category assign to the product, specified by product id | 
 **storeId** | **string** | Store Id | 
 **idempotencyKey** | **string** | A unique identifier associated with a specific request. Repeated requests with the same &lt;strong&gt;idempotency_key&lt;/strong&gt; return a cached response without re-executing the business logic. &lt;strong&gt;Please note that the cache lifetime is 15 minutes.&lt;/strong&gt; | 

### Return type

[**ModelResponseCategoryAssign**](ModelResponseCategoryAssign.md)

### Authorization

[StoreKeyAuth](../README.md#StoreKeyAuth), [ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CategoryCount

> ModelResponseCategoryCount CategoryCount(ctx).ParentId(parentId).StoreId(storeId).LangId(langId).Avail(avail).CreatedFrom(createdFrom).CreatedTo(createdTo).ModifiedFrom(modifiedFrom).ModifiedTo(modifiedTo).ProductType(productType).FindValue(findValue).FindWhere(findWhere).ReportRequestId(reportRequestId).DisableReportCache(disableReportCache).Execute()

category.count



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	parentId := "6" // string | Counts categories specified by parent id (optional)
	storeId := "1" // string | Counts category specified by store id (optional)
	langId := "3" // string | Counts category specified by language id (optional)
	avail := false // bool | Defines category's visibility status (optional) (default to true)
	createdFrom := "2010-07-29 13:45:52" // string | Retrieve entities from their creation date (optional)
	createdTo := "2100-08-29 13:45:52" // string | Retrieve entities to their creation date (optional)
	modifiedFrom := "2010-07-29 13:45:52" // string | Retrieve entities from their modification date (optional)
	modifiedTo := "2100-08-29 13:45:52" // string | Retrieve entities to their modification date (optional)
	productType := "BICYCLE" // string | A categorization for the product (optional)
	findValue := "Demo category 1" // string | Entity search that is specified by some value (optional)
	findWhere := "email" // string | Counts categories that are searched specified by field (optional)
	reportRequestId := "105245017661" // string | Report request id (optional)
	disableReportCache := false // bool | Disable report cache for current request (optional) (default to false)

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.CategoryAPI.CategoryCount(context.Background()).ParentId(parentId).StoreId(storeId).LangId(langId).Avail(avail).CreatedFrom(createdFrom).CreatedTo(createdTo).ModifiedFrom(modifiedFrom).ModifiedTo(modifiedTo).ProductType(productType).FindValue(findValue).FindWhere(findWhere).ReportRequestId(reportRequestId).DisableReportCache(disableReportCache).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `CategoryAPI.CategoryCount``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `CategoryCount`: ModelResponseCategoryCount
	fmt.Fprintf(os.Stdout, "Response from `CategoryAPI.CategoryCount`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCategoryCountRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **parentId** | **string** | Counts categories specified by parent id | 
 **storeId** | **string** | Counts category specified by store id | 
 **langId** | **string** | Counts category specified by language id | 
 **avail** | **bool** | Defines category&#39;s visibility status | [default to true]
 **createdFrom** | **string** | Retrieve entities from their creation date | 
 **createdTo** | **string** | Retrieve entities to their creation date | 
 **modifiedFrom** | **string** | Retrieve entities from their modification date | 
 **modifiedTo** | **string** | Retrieve entities to their modification date | 
 **productType** | **string** | A categorization for the product | 
 **findValue** | **string** | Entity search that is specified by some value | 
 **findWhere** | **string** | Counts categories that are searched specified by field | 
 **reportRequestId** | **string** | Report request id | 
 **disableReportCache** | **bool** | Disable report cache for current request | [default to false]

### Return type

[**ModelResponseCategoryCount**](ModelResponseCategoryCount.md)

### Authorization

[StoreKeyAuth](../README.md#StoreKeyAuth), [ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CategoryDelete

> CategoryDelete200Response CategoryDelete(ctx).Id(id).StoreId(storeId).Execute()

category.delete



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	id := "10" // string | Defines category removal, specified by category id
	storeId := "1" // string | Store Id (optional)

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.CategoryAPI.CategoryDelete(context.Background()).Id(id).StoreId(storeId).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `CategoryAPI.CategoryDelete``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `CategoryDelete`: CategoryDelete200Response
	fmt.Fprintf(os.Stdout, "Response from `CategoryAPI.CategoryDelete`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCategoryDeleteRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **string** | Defines category removal, specified by category id | 
 **storeId** | **string** | Store Id | 

### Return type

[**CategoryDelete200Response**](CategoryDelete200Response.md)

### Authorization

[StoreKeyAuth](../README.md#StoreKeyAuth), [ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CategoryDeleteBatch

> CategoryAddBatch200Response CategoryDeleteBatch(ctx).CategoryDeleteBatch(categoryDeleteBatch).Execute()

category.delete.batch



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	categoryDeleteBatch := *openapiclient.NewCategoryDeleteBatch([]openapiclient.CategoryDeleteBatchPayloadInner{*openapiclient.NewCategoryDeleteBatchPayloadInner("Id_example")}) // CategoryDeleteBatch | 

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.CategoryAPI.CategoryDeleteBatch(context.Background()).CategoryDeleteBatch(categoryDeleteBatch).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `CategoryAPI.CategoryDeleteBatch``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `CategoryDeleteBatch`: CategoryAddBatch200Response
	fmt.Fprintf(os.Stdout, "Response from `CategoryAPI.CategoryDeleteBatch`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCategoryDeleteBatchRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **categoryDeleteBatch** | [**CategoryDeleteBatch**](CategoryDeleteBatch.md) |  | 

### Return type

[**CategoryAddBatch200Response**](CategoryAddBatch200Response.md)

### Authorization

[StoreKeyAuth](../README.md#StoreKeyAuth), [ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CategoryFind

> ModelResponseCategoryFind CategoryFind(ctx).FindValue(findValue).FindWhere(findWhere).FindParams(findParams).StoreId(storeId).LangId(langId).Execute()

category.find



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	findValue := "Demo category 1" // string | Entity search that is specified by some value
	findWhere := "name" // string | Entity search that is specified by the comma-separated unique fields (optional) (default to "name")
	findParams := "regex" // string | Entity search that is specified by comma-separated parameters (optional) (default to "whole_words")
	storeId := "1" // string | Store Id (optional)
	langId := "3" // string | Language id (optional)

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.CategoryAPI.CategoryFind(context.Background()).FindValue(findValue).FindWhere(findWhere).FindParams(findParams).StoreId(storeId).LangId(langId).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `CategoryAPI.CategoryFind``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `CategoryFind`: ModelResponseCategoryFind
	fmt.Fprintf(os.Stdout, "Response from `CategoryAPI.CategoryFind`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCategoryFindRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **findValue** | **string** | Entity search that is specified by some value | 
 **findWhere** | **string** | Entity search that is specified by the comma-separated unique fields | [default to &quot;name&quot;]
 **findParams** | **string** | Entity search that is specified by comma-separated parameters | [default to &quot;whole_words&quot;]
 **storeId** | **string** | Store Id | 
 **langId** | **string** | Language id | 

### Return type

[**ModelResponseCategoryFind**](ModelResponseCategoryFind.md)

### Authorization

[StoreKeyAuth](../README.md#StoreKeyAuth), [ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CategoryImageAdd

> CategoryImageAdd200Response CategoryImageAdd(ctx).CategoryId(categoryId).ImageName(imageName).Url(url).Type_(type_).StoreId(storeId).Label(label).Mime(mime).Position(position).ApplyToTranslations(applyToTranslations).IdempotencyKey(idempotencyKey).Execute()

category.image.add



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	categoryId := "6" // string | Defines category id where the image should be added
	imageName := "bag-gray.png" // string | Defines image's name
	url := "http://docs.api2cart.com/img/logo.png" // string | Defines URL of the image that has to be added
	type_ := "base" // string | Defines image's types that are specified by comma-separated list
	storeId := "1" // string | Store Id (optional)
	label := "This cool image" // string | Defines alternative text that has to be attached to the picture (optional)
	mime := "image/jpeg" // string | Mime type of image http://en.wikipedia.org/wiki/Internet_media_type. (optional)
	position := int32(5) // int32 | Defines image’s position in the list (optional) (default to 0)
	applyToTranslations := true // bool | Defines whether to add image to all category translations (optional) (default to true)
	idempotencyKey := "098f6bcd4621d373cade4e832627b4f6" // string | A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> (optional)

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.CategoryAPI.CategoryImageAdd(context.Background()).CategoryId(categoryId).ImageName(imageName).Url(url).Type_(type_).StoreId(storeId).Label(label).Mime(mime).Position(position).ApplyToTranslations(applyToTranslations).IdempotencyKey(idempotencyKey).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `CategoryAPI.CategoryImageAdd``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `CategoryImageAdd`: CategoryImageAdd200Response
	fmt.Fprintf(os.Stdout, "Response from `CategoryAPI.CategoryImageAdd`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCategoryImageAddRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **categoryId** | **string** | Defines category id where the image should be added | 
 **imageName** | **string** | Defines image&#39;s name | 
 **url** | **string** | Defines URL of the image that has to be added | 
 **type_** | **string** | Defines image&#39;s types that are specified by comma-separated list | 
 **storeId** | **string** | Store Id | 
 **label** | **string** | Defines alternative text that has to be attached to the picture | 
 **mime** | **string** | Mime type of image http://en.wikipedia.org/wiki/Internet_media_type. | 
 **position** | **int32** | Defines image’s position in the list | [default to 0]
 **applyToTranslations** | **bool** | Defines whether to add image to all category translations | [default to true]
 **idempotencyKey** | **string** | A unique identifier associated with a specific request. Repeated requests with the same &lt;strong&gt;idempotency_key&lt;/strong&gt; return a cached response without re-executing the business logic. &lt;strong&gt;Please note that the cache lifetime is 15 minutes.&lt;/strong&gt; | 

### Return type

[**CategoryImageAdd200Response**](CategoryImageAdd200Response.md)

### Authorization

[StoreKeyAuth](../README.md#StoreKeyAuth), [ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CategoryImageDelete

> AttributeDelete200Response CategoryImageDelete(ctx).CategoryId(categoryId).ImageId(imageId).StoreId(storeId).ApplyToTranslations(applyToTranslations).Execute()

category.image.delete



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	categoryId := "6" // string | Defines category id where the image should be deleted
	imageId := "82950b84f468edff480680f99cedbe0d" // string | Define image id
	storeId := "1" // string | Store Id (optional)
	applyToTranslations := false // bool | Defines whether to delete image from all category translations (optional) (default to true)

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.CategoryAPI.CategoryImageDelete(context.Background()).CategoryId(categoryId).ImageId(imageId).StoreId(storeId).ApplyToTranslations(applyToTranslations).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `CategoryAPI.CategoryImageDelete``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `CategoryImageDelete`: AttributeDelete200Response
	fmt.Fprintf(os.Stdout, "Response from `CategoryAPI.CategoryImageDelete`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCategoryImageDeleteRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **categoryId** | **string** | Defines category id where the image should be deleted | 
 **imageId** | **string** | Define image id | 
 **storeId** | **string** | Store Id | 
 **applyToTranslations** | **bool** | Defines whether to delete image from all category translations | [default to true]

### Return type

[**AttributeDelete200Response**](AttributeDelete200Response.md)

### Authorization

[StoreKeyAuth](../README.md#StoreKeyAuth), [ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CategoryInfo

> CategoryInfo200Response CategoryInfo(ctx).Id(id).StoreId(storeId).LangId(langId).SchemaType(schemaType).ResponseFields(responseFields).Params(params).Exclude(exclude).ReportRequestId(reportRequestId).DisableReportCache(disableReportCache).UseLatestApiVersion(useLatestApiVersion).Execute()

category.info



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	id := "10" // string | Retrieves category's info specified by category id
	storeId := "1" // string | Retrieves category info  specified by store id (optional)
	langId := "3" // string | Retrieves category info  specified by language id (optional)
	schemaType := "LISTING" // string | The name of the requirements set for the provided schema. (optional)
	responseFields := "{result{id,name,parent_id,modified_at{value},images}}" // string | Set this parameter in order to choose which entity fields you want to retrieve (optional)
	params := "id,parent_id,name" // string | Set this parameter in order to choose which entity fields you want to retrieve (optional) (default to "id,parent_id,name,description")
	exclude := "id,parent_id,name" // string | Set this parameter in order to choose which entity fields you want to ignore. Works only if parameter `params` equal force_all (optional)
	reportRequestId := "105245017661" // string | Report request id (optional)
	disableReportCache := false // bool | Disable report cache for current request (optional) (default to false)
	useLatestApiVersion := true // bool | Use the latest platform API version (optional) (default to false)

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.CategoryAPI.CategoryInfo(context.Background()).Id(id).StoreId(storeId).LangId(langId).SchemaType(schemaType).ResponseFields(responseFields).Params(params).Exclude(exclude).ReportRequestId(reportRequestId).DisableReportCache(disableReportCache).UseLatestApiVersion(useLatestApiVersion).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `CategoryAPI.CategoryInfo``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `CategoryInfo`: CategoryInfo200Response
	fmt.Fprintf(os.Stdout, "Response from `CategoryAPI.CategoryInfo`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCategoryInfoRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **string** | Retrieves category&#39;s info specified by category id | 
 **storeId** | **string** | Retrieves category info  specified by store id | 
 **langId** | **string** | Retrieves category info  specified by language id | 
 **schemaType** | **string** | The name of the requirements set for the provided schema. | 
 **responseFields** | **string** | Set this parameter in order to choose which entity fields you want to retrieve | 
 **params** | **string** | Set this parameter in order to choose which entity fields you want to retrieve | [default to &quot;id,parent_id,name,description&quot;]
 **exclude** | **string** | Set this parameter in order to choose which entity fields you want to ignore. Works only if parameter &#x60;params&#x60; equal force_all | 
 **reportRequestId** | **string** | Report request id | 
 **disableReportCache** | **bool** | Disable report cache for current request | [default to false]
 **useLatestApiVersion** | **bool** | Use the latest platform API version | [default to false]

### Return type

[**CategoryInfo200Response**](CategoryInfo200Response.md)

### Authorization

[StoreKeyAuth](../README.md#StoreKeyAuth), [ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CategoryList

> ModelResponseCategoryList CategoryList(ctx).Start(start).Count(count).PageCursor(pageCursor).StoreId(storeId).LangId(langId).ParentId(parentId).Avail(avail).ProductType(productType).CreatedFrom(createdFrom).CreatedTo(createdTo).ModifiedFrom(modifiedFrom).ModifiedTo(modifiedTo).FindValue(findValue).FindWhere(findWhere).ResponseFields(responseFields).Params(params).Exclude(exclude).ReportRequestId(reportRequestId).DisableReportCache(disableReportCache).DisableCache(disableCache).UseLatestApiVersion(useLatestApiVersion).Execute()

category.list



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	start := int32(0) // int32 | This parameter sets the number from which you want to get entities (optional) (default to 0)
	count := int32(20) // int32 | This parameter sets the entity amount that has to be retrieved. Max allowed count=250 (optional) (default to 10)
	pageCursor := "pageCursor_example" // string | Used to retrieve entities via cursor-based pagination (it can't be used with any other filtering parameter) (optional)
	storeId := "1" // string | Retrieves categories specified by store id (optional)
	langId := "3" // string | Retrieves categorys specified by language id (optional)
	parentId := "6" // string | Retrieves categories specified by parent id (optional)
	avail := false // bool | Defines category's visibility status (optional) (default to true)
	productType := "BICYCLE" // string | A categorization for the product (optional)
	createdFrom := "2010-07-29 13:45:52" // string | Retrieve entities from their creation date (optional)
	createdTo := "2100-08-29 13:45:52" // string | Retrieve entities to their creation date (optional)
	modifiedFrom := "2010-07-29 13:45:52" // string | Retrieve entities from their modification date (optional)
	modifiedTo := "2100-08-29 13:45:52" // string | Retrieve entities to their modification date (optional)
	findValue := "Demo category 1" // string | Entity search that is specified by some value (optional)
	findWhere := "name" // string | Category search that is specified by field (optional)
	responseFields := "{result{categories_count,category{id,parent_id,modified_at{value},images}}}" // string | Set this parameter in order to choose which entity fields you want to retrieve (optional)
	params := "id,parent_id,name" // string | Set this parameter in order to choose which entity fields you want to retrieve (optional) (default to "id,parent_id,name,description")
	exclude := "id,parent_id,name" // string | Set this parameter in order to choose which entity fields you want to ignore. Works only if parameter `params` equal force_all (optional)
	reportRequestId := "105245017661" // string | Report request id (optional)
	disableReportCache := false // bool | Disable report cache for current request (optional) (default to false)
	disableCache := false // bool | Disable cache for current request (optional) (default to false)
	useLatestApiVersion := true // bool | Use the latest platform API version (optional) (default to false)

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.CategoryAPI.CategoryList(context.Background()).Start(start).Count(count).PageCursor(pageCursor).StoreId(storeId).LangId(langId).ParentId(parentId).Avail(avail).ProductType(productType).CreatedFrom(createdFrom).CreatedTo(createdTo).ModifiedFrom(modifiedFrom).ModifiedTo(modifiedTo).FindValue(findValue).FindWhere(findWhere).ResponseFields(responseFields).Params(params).Exclude(exclude).ReportRequestId(reportRequestId).DisableReportCache(disableReportCache).DisableCache(disableCache).UseLatestApiVersion(useLatestApiVersion).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `CategoryAPI.CategoryList``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `CategoryList`: ModelResponseCategoryList
	fmt.Fprintf(os.Stdout, "Response from `CategoryAPI.CategoryList`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCategoryListRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **start** | **int32** | This parameter sets the number from which you want to get entities | [default to 0]
 **count** | **int32** | This parameter sets the entity amount that has to be retrieved. Max allowed count&#x3D;250 | [default to 10]
 **pageCursor** | **string** | Used to retrieve entities via cursor-based pagination (it can&#39;t be used with any other filtering parameter) | 
 **storeId** | **string** | Retrieves categories specified by store id | 
 **langId** | **string** | Retrieves categorys specified by language id | 
 **parentId** | **string** | Retrieves categories specified by parent id | 
 **avail** | **bool** | Defines category&#39;s visibility status | [default to true]
 **productType** | **string** | A categorization for the product | 
 **createdFrom** | **string** | Retrieve entities from their creation date | 
 **createdTo** | **string** | Retrieve entities to their creation date | 
 **modifiedFrom** | **string** | Retrieve entities from their modification date | 
 **modifiedTo** | **string** | Retrieve entities to their modification date | 
 **findValue** | **string** | Entity search that is specified by some value | 
 **findWhere** | **string** | Category search that is specified by field | 
 **responseFields** | **string** | Set this parameter in order to choose which entity fields you want to retrieve | 
 **params** | **string** | Set this parameter in order to choose which entity fields you want to retrieve | [default to &quot;id,parent_id,name,description&quot;]
 **exclude** | **string** | Set this parameter in order to choose which entity fields you want to ignore. Works only if parameter &#x60;params&#x60; equal force_all | 
 **reportRequestId** | **string** | Report request id | 
 **disableReportCache** | **bool** | Disable report cache for current request | [default to false]
 **disableCache** | **bool** | Disable cache for current request | [default to false]
 **useLatestApiVersion** | **bool** | Use the latest platform API version | [default to false]

### Return type

[**ModelResponseCategoryList**](ModelResponseCategoryList.md)

### Authorization

[StoreKeyAuth](../README.md#StoreKeyAuth), [ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CategoryUnassign

> ModelResponseCategoryUnassign CategoryUnassign(ctx).CategoryId(categoryId).ProductId(productId).StoreId(storeId).IdempotencyKey(idempotencyKey).Execute()

category.unassign



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	categoryId := "6" // string | Defines category unassign, specified by category id
	productId := "10" // string | Defines category unassign to the product, specified by product id
	storeId := "1" // string | Store Id (optional)
	idempotencyKey := "098f6bcd4621d373cade4e832627b4f6" // string | A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> (optional)

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.CategoryAPI.CategoryUnassign(context.Background()).CategoryId(categoryId).ProductId(productId).StoreId(storeId).IdempotencyKey(idempotencyKey).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `CategoryAPI.CategoryUnassign``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `CategoryUnassign`: ModelResponseCategoryUnassign
	fmt.Fprintf(os.Stdout, "Response from `CategoryAPI.CategoryUnassign`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCategoryUnassignRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **categoryId** | **string** | Defines category unassign, specified by category id | 
 **productId** | **string** | Defines category unassign to the product, specified by product id | 
 **storeId** | **string** | Store Id | 
 **idempotencyKey** | **string** | A unique identifier associated with a specific request. Repeated requests with the same &lt;strong&gt;idempotency_key&lt;/strong&gt; return a cached response without re-executing the business logic. &lt;strong&gt;Please note that the cache lifetime is 15 minutes.&lt;/strong&gt; | 

### Return type

[**ModelResponseCategoryUnassign**](ModelResponseCategoryUnassign.md)

### Authorization

[StoreKeyAuth](../README.md#StoreKeyAuth), [ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CategoryUpdate

> AccountConfigUpdate200Response CategoryUpdate(ctx).Id(id).Name(name).Description(description).ShortDescription(shortDescription).ParentId(parentId).Avail(avail).SortOrder(sortOrder).ModifiedTime(modifiedTime).MetaTitle(metaTitle).MetaDescription(metaDescription).MetaKeywords(metaKeywords).SeoUrl(seoUrl).StoreId(storeId).StoresIds(storesIds).LangId(langId).IdempotencyKey(idempotencyKey).Execute()

category.update



### Example

```go
package main

import (
	"context"
	"fmt"
	"os"
	openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
	id := "10" // string | Defines category update specified by category id
	name := "NEW Shoes" // string | Defines new category’s name (optional)
	description := "New test category" // string | Defines new category's description (optional)
	shortDescription := "Short description. This is very short description" // string | Defines short description (optional)
	parentId := "6" // string | Defines new parent category id (optional)
	avail := false // bool | Defines category's visibility status (optional)
	sortOrder := int32(2) // int32 | Sort number in the list (optional)
	modifiedTime := "2014-07-30 15:58:41" // string | Entity's date modification (optional)
	metaTitle := "category,test" // string | Defines unique meta title for each entity (optional)
	metaDescription := "category,test" // string | Defines unique meta description of a entity (optional)
	metaKeywords := "category,test" // string | Defines unique meta keywords for each entity (optional)
	seoUrl := "category,test" // string | Defines unique category's URL for SEO (optional)
	storeId := "1" // string | Store Id (optional)
	storesIds := "1,2" // string | Update category in the stores that is specified by comma-separated stores' id (optional)
	langId := "3" // string | Language id (optional)
	idempotencyKey := "098f6bcd4621d373cade4e832627b4f6" // string | A unique identifier associated with a specific request. Repeated requests with the same <strong>idempotency_key</strong> return a cached response without re-executing the business logic. <strong>Please note that the cache lifetime is 15 minutes.</strong> (optional)

	configuration := openapiclient.NewConfiguration()
	apiClient := openapiclient.NewAPIClient(configuration)
	resp, r, err := apiClient.CategoryAPI.CategoryUpdate(context.Background()).Id(id).Name(name).Description(description).ShortDescription(shortDescription).ParentId(parentId).Avail(avail).SortOrder(sortOrder).ModifiedTime(modifiedTime).MetaTitle(metaTitle).MetaDescription(metaDescription).MetaKeywords(metaKeywords).SeoUrl(seoUrl).StoreId(storeId).StoresIds(storesIds).LangId(langId).IdempotencyKey(idempotencyKey).Execute()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error when calling `CategoryAPI.CategoryUpdate``: %v\n", err)
		fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
	}
	// response from `CategoryUpdate`: AccountConfigUpdate200Response
	fmt.Fprintf(os.Stdout, "Response from `CategoryAPI.CategoryUpdate`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCategoryUpdateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **string** | Defines category update specified by category id | 
 **name** | **string** | Defines new category’s name | 
 **description** | **string** | Defines new category&#39;s description | 
 **shortDescription** | **string** | Defines short description | 
 **parentId** | **string** | Defines new parent category id | 
 **avail** | **bool** | Defines category&#39;s visibility status | 
 **sortOrder** | **int32** | Sort number in the list | 
 **modifiedTime** | **string** | Entity&#39;s date modification | 
 **metaTitle** | **string** | Defines unique meta title for each entity | 
 **metaDescription** | **string** | Defines unique meta description of a entity | 
 **metaKeywords** | **string** | Defines unique meta keywords for each entity | 
 **seoUrl** | **string** | Defines unique category&#39;s URL for SEO | 
 **storeId** | **string** | Store Id | 
 **storesIds** | **string** | Update category in the stores that is specified by comma-separated stores&#39; id | 
 **langId** | **string** | Language id | 
 **idempotencyKey** | **string** | A unique identifier associated with a specific request. Repeated requests with the same &lt;strong&gt;idempotency_key&lt;/strong&gt; return a cached response without re-executing the business logic. &lt;strong&gt;Please note that the cache lifetime is 15 minutes.&lt;/strong&gt; | 

### Return type

[**AccountConfigUpdate200Response**](AccountConfigUpdate200Response.md)

### Authorization

[StoreKeyAuth](../README.md#StoreKeyAuth), [ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

